/**
 * @author Shane Hagan
 * Project: Loops Practice Assignment TEKJava
 */

package com.hagan.loops;

public class LoopPractice {

	public static void main(String[] args) {
		printMultiplicationTable();
		findGreatestCommonDivisor();
		calculateDoubleTuition();
	}
	
	public static void printMultiplicationTable() {
		for (int i = 1; i < 13; i++) {
			for (int j = 1; j < 13; j++) {
				System.out.print(i*j + "\t");;
			}
			System.out.print("\n");
		}
		System.out.print("\n");
	}
	
	public static void findGreatestCommonDivisor() {
		int gcd = 0, x = 24, y = 16;
		for (int i = 1; i <= x && i <= y; i++) {
			if (x % i == 0 & y % i == 0) {
				gcd = i;
			}
		}
		System.out.println("The Greatest Common Divisor (GCD) of " + x + " and " + y + " is " + gcd);
		System.out.println("\n");
	}
	
	public static void calculateDoubleTuition() {
		double tuition = 10000;
		int duration;
		
		for (duration = 0; tuition < 20000; duration++) {
			tuition = 1.07 * tuition;
		}
		System.out.println("It will take " + duration + " months for the tuition to double to $20,000");
	}

}
